<?php $__env->startSection('links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('style/modal-tutor.css')); ?>"/>

    <link rel="stylesheet" href="<?php echo e(asset('dist/css/bootstrap-select-v2.css')); ?>">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">
<style>

</style>
<?php $__env->stopSection(); ?>
<!-- Modal HTML -->
<div id="myModal" class="modal fade">
    <div class="modal-dialog modal-confirm" style="max-width: none;width: 600px">
        <div class="modal-content">
            <div class="modal-header justify-content-center">
                <div class="icon-box">
                    <i class="fa fa-user-circle"></i>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
            </div>
            <div class="modal-body text-center">
                <h4>Great!</h4>
                <p>Your are almost here to book your first free tutor.</p>
                     <!-- Register Contact Form -->
                    <div class="row">
                        <div class="col-12">
                            <div class="forms">
                            <span id="response_message"></span>
                                <form class="tutor_free_request_form" id="tutor_free_request_form" action="<?php echo e(route('site.tutor.request')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" name="fname" class="form-control" id="text" placeholder="First Name">
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" name="lname" class="form-control" id="lname" placeholder="Last Name">
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" name="phone" class="form-control" id="phone" placeholder="Phone">
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="email" class="form-control" name="email" id="email" placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="rate" id="" placeholder="Rate /hr eg $10-30/hr">
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="area" id="" placeholder="Area Postal Code">

                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-lg-12 col-md-12">
                                            <div class="form-group">
                                                <textarea class="form-control"   placeholder="Enter Requirement Message (optional)" name="description"></textarea>

                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-lg-12 col-md-12" id="add_level_grade">
                                            <div class="form-group" style="">
                                                <select class="form-control" name="level_grade[grades][]">
                                                   <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                       <option value="" style="color: #00d69f" disabled><h5 style="color: #00d69f"><?php echo e($level->level_title); ?></h5></option>
                                                       <?php $__currentLoopData = $level->grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                           <option value="<?php echo e($grade->grade_id); ?>"><?php echo e($grade->grade_title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group" style="">
                                                <select name="subjects[0][]"  class="selectpicker show-menu-arrow"  multiple>
                                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($subject->subject_id); ?>"><?php echo e($subject->subject_title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>



                                        <div class="col-sm-12 col-lg-12 col-md-12">
                                            <div class="form-group">
                                                 <a href="javascript:;" onclick="addAnotherTutorRequestFormRow(<?php echo e(json_encode($levels)); ?>,<?php echo e($subjects); ?>)"> <i class="fa fa-plus"></i> &nbsp;&nbsp; Add Another Student</a>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <button type="submit"   class="btnn clever-btn w-100">Find Tutor</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>




            </div>
        </div>
    </div>
</div>

<?php $__env->startSection('scripts'); ?>
    <script>
        var index = 1;
        function addAnotherTutorRequestFormRow(options,subjects){

            var select = '<div class="form-group"><select class="form-control" name="level_grade[grades][]">';


            options.map(option=>{
                select+=' <option value="" style="color: #00d69f" disabled><h5 style="color: #00d69f">'+option.level_title+'</h5></option>';
                option.grades.map(grade=>{
                    select+='<option value="'+grade.grade_id+'">'+grade.grade_title+'</option>';
                })
            })

            select+='</select></div>';


            var subjects_select = '<div class="form-group"><select name="subjects['+index+'][]"  class="selectpicker show-menu-arrow"  multiple>';
            subjects.map(subject=>{
                subjects_select+='<option value="'+subject.subject_id+'">'+subject.subject_title+'</option>';
            })
            subjects_select+='</select></div>';



            index+=1;
            const html = select + subjects_select;
            document.getElementById('add_level_grade').insertAdjacentHTML('beforeend',html)
            $('.selectpicker').selectpicker();
        }
    </script>
    <script src="<?php echo e(asset('dist/js/bootstrap-select.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/vagrant/code/onlinetutor/resources/views/layouts/components/modal.blade.php ENDPATH**/ ?>