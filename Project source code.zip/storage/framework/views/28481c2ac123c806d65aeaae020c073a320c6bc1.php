<?php $__env->startSection('title','Tutor | Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="col-lg-8 col-xl-9">

        <div class="sl-dashboardbox">
            <div class="sl-dashboardbox__title">
                <h2>Dashboard </h2>
            </div>
            <div class="sl-dashboardbox__content">
                <form class="sl-form sl-deactivateac">
                    <fieldset>
                        <div class="sl-form__wrap">
                            <?php if($tutor->profile_approved == 0): ?>
                                <div class="alert alert-primary">
                                    Your Profile is currently under processing. We will let you know once you are approved by admin
                                </div>
                                <?php else: ?>
                                <div class="alert alert-success">
                                    Your Profile has been approved successfully by administration
                                </div>
                            <?php endif; ?>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('application.dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/onlinetutor/resources/views/application/dashboard/welcome.blade.php ENDPATH**/ ?>