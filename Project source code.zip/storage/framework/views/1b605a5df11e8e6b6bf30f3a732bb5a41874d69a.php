<?php $__env->startSection('title','Site | Home'); ?>
<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>"/>
    <style>
        #toast {
            visibility: hidden;
            max-width: 50px;
            height: 50px;
            /*margin-left: -125px;*/
            margin: auto;
            background-color: #333;
            color: #fff;
            text-align: center;
            border-radius: 2px;

            position: fixed;
            z-index: 1;
            left: 0;right:0;
            bottom: 30px;
            font-size: 17px;
            white-space: nowrap;
        }
        #toast #img{
            width: 50px;
            height: 50px;

            float: left;

            padding-top: 16px;
            padding-bottom: 16px;

            box-sizing: border-box;


            background-color: #111;
            color: #fff;
        }
        #toast #desc{


            color: #fff;

            padding: 16px;

            overflow: hidden;
            white-space: nowrap;
        }

        #toast.show {
            visibility: visible;
            -webkit-animation: fadein 0.5s, expand 0.5s 0.5s,stay 3s 1s, shrink 0.5s 2s, fadeout 0.5s 2.5s;
            animation: fadein 0.5s, expand 0.5s 0.5s,stay 3s 1s, shrink 0.5s 4s, fadeout 0.5s 4.5s;
        }

        @-webkit-keyframes fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }

        @keyframes  fadein {
            from {bottom: 0; opacity: 0;}
            to {bottom: 30px; opacity: 1;}
        }

        @-webkit-keyframes expand {
            from {min-width: 50px}
            to {min-width: 350px}
        }

        @keyframes  expand {
            from {min-width: 50px}
            to {min-width: 350px}
        }
        @-webkit-keyframes stay {
            from {min-width: 350px}
            to {min-width: 350px}
        }

        @keyframes  stay {
            from {min-width: 350px}
            to {min-width: 350px}
        }
        @-webkit-keyframes shrink {
            from {min-width: 350px;}
            to {min-width: 50px;}
        }

        @keyframes  shrink {
            from {min-width: 350px;}
            to {min-width: 50px;}
        }

        @-webkit-keyframes fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 60px; opacity: 0;}
        }

        @keyframes  fadeout {
            from {bottom: 30px; opacity: 1;}
            to {bottom: 60px; opacity: 0;}
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


  <div class="container">
      <div id="toast">
          <div id="img">Icon</div>
          <div id="desc">A notification message..</div>
      </div>

       <div class="row">
           <div class="col-sm">
               <div class="signup-form">
                   <h6>Are you looking for tuition assignments or music students?</h6>
                   <p>Start Tuition receive more than 100 new tutoring requests from parents every week. Get suitable home tuition jobs:</p>
                   <p><i class="fa fa-check" style="color: #00d69f"> </i>&nbsp;&nbsp;for your preferred levels and subjects</p>
                   <p><i class="fa fa-check" style="color: #00d69f"> </i> &nbsp;&nbsp;within your asking rates</p>
                   <p><i class="fa fa-check" style="color: #00d69f"> </i>&nbsp;&nbsp; at your preferred locations</p>

                   <p>Primary school assignments, secondary school assignments, English tuition, Maths tuition, Piano lessons etc are all available here.
                   </p>

                   <span><i class="fa fa-times" style="color: #b21f2d"></i> If you're above 18 years old and a Singapore citizen, Singapore PR, or a valid Student Pass holder,</span>
               </div>

               <div class="signup-form">
                   <p>
                       Average hourly rates for different tutor categories for academic tuition jobs (Pri, Sec, JC, IB, Diploma, Degree tuition)
                   </p>

                   <small>* Final rates depends on your qualifications, years of experience and track record.</small>

                   <table class="table table-hover">
                       <thead>
                       <tr style="background-color: #00d69f;color: white">
                           <td></td>
                           <td>Full Time Students</td>
                           <td>Private Tutors</td>
                           <td>MOE School Teachers</td>
                       </tr>
                       </thead>
                       <tbody>
                       <tr>
                           <td>Preschool</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                       </tr>
                       <tr>
                           <td>Preschool</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                       </tr>
                       <tr>
                           <td>Preschool</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                       </tr>
                       <tr>
                           <td>Preschool</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                           <td>$18 to $25</td>
                       </tr>

                       </tbody>
                   </table>

               </div>
           </div>
           <div class="col-sm">
               <?php generateFlashMessage();?>
               <div class="signup-form">
                   <form action="<?php echo e(route('site.tutor.register')); ?>" method="post">
                       <?php echo csrf_field(); ?>
                       <h2>Create an Account</h2>
                       <p class="hint-text">Sign up with your social media account or email address</p>
                       <div class="social-btn text-center">
                           <a href="#" class="btn btn-primary btn-lg"><i class="fa fa-facebook"></i> Facebook</a>
                           <a href="#" class="btn btn-info btn-lg"><i class="fa fa-twitter"></i> Twitter</a>
                           <a href="<?php echo e(url('/auth/redirect')); ?>" class="btn btn-danger btn-lg"><i class="fa fa-google"></i> Google</a>
                       </div>
                       <div class="or-seperator"><b>or</b></div>
                       <div class="form-group">
                           <input type="text" class="form-control input-sm" name="name" value="<?php if(isset($user)) { echo $user['name']; }?>" placeholder="Your Name" required="required">
                       </div>

                       <div class="form-group">
                           <input type="email" class="form-control input-lg" name="email" value="<?php if(isset($user)) { echo $user['email']; }?>" placeholder="Email Address" required="required">
                       </div>
                       <div class="form-group">
                           <input type="password" class="form-control input-lg" name="password" value="atif" placeholder="Password" required="required">
                       </div>
                       <div class="form-group">
                           <input type="password" class="form-control input-lg" name="confirm_password" value="atif" placeholder="Confirm Password" required="required">
                       </div>
                       <div class="form-group">
                           <button type="submit" class="btn btn-success btn-lg btn-block signup-btn">Sign Up</button>
                       </div>
                   </form>
                   <div class="text-center">Already have an account? <a href="#">Login here</a></div>
               </div>
           </div>
       </div>


    </div>
<button onclick="launch_toast()">click</button>
<?php $__env->stopSection(); ?>
<script>
    function launch_toast() {
        var x = document.getElementById("toast")
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 5000);
    }
    //launch_toast();
</script>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/onlinetutor/resources/views/auths/pages/register.blade.php ENDPATH**/ ?>