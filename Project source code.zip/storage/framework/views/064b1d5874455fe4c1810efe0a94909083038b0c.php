Please click the link to verify your account.

<a href="<?php echo e(route('site.email-verification',['email'=>$email,'token'=>$token])); ?>">Verify</a>
<?php /**PATH /home/vagrant/code/onlinetutor/resources/views/emails/account-verification.blade.php ENDPATH**/ ?>