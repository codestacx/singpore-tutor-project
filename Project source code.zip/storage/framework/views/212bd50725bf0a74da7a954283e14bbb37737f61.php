<footer class="main-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <p>Your company &copy; 2017-2020</p>
            </div>
            <div class="col-sm-6 text-right">
                <p>Version 1.4.7</p>
            </div>
        </div>
    </div>
</footer>
</div>
<!-- JavaScript files-->
<script src="<?php echo e(asset('admin/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/grasp_mobile_progress_circle-1.0.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/jquery.cookie/jquery.cookie.js')); ?>"> </script>
<script src="<?php echo e(asset('admin/vendor/chart.js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/jquery-validation/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/charts-home.js')); ?>"></script>
<!-- Notifications-->
<script src="<?php echo e(asset('admin/vendor/messenger-hubspot/build/js/messenger.min.js')); ?>">   </script>
<script src="<?php echo e(asset('admin/vendor/messenger-hubspot/build/js/messenger-theme-flat.js')); ?>">       </script>
<script src="<?php echo e(asset('admin/js/home-premium.js')); ?>"> </script>
<!-- Main File-->
<script src="<?php echo e(asset('admin/js/front.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH /home/vagrant/code/onlinetutor/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>