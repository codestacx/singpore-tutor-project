<?php $__env->startSection('title','Grades'); ?>
<?php $__env->startSection('content'); ?>
    <div class="breadcrumb-holder">
        <div class="container-fluid">
            <ul class="breadcrumb">
                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                <li class="breadcrumb-item active">Forms       </li>
            </ul>
        </div>
    </div>
    <section class="forms">
        <div class="container-fluid">
            <!-- Page Header-->
            
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex align-items-center">
                            <h4><?php echo e(isset($location) ? 'Update Location':'Add Location'); ?></h4>
                        </div>
                        <?php generateFlashMessage(); ?>
                        <div class="card-body">
                            <form method="post" action="<?php echo e(route('admin.locations')); ?>">
                                <?php echo csrf_field(); ?>
                                <?php if(isset($location)): ?>
                                    <input type="hidden" value="<?php echo e($location->location_id); ?>" name="location"/>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label>Location Title</label>
                                            <input type="text" name="title" value="<?php echo e(isset($location) ? $location->location_title:''); ?>" placeholder="Location Title" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-group" style="padding-top: 30px !important;">
                                            <input type="submit" value="<?php echo e(isset($location) ? 'Update':'Submit'); ?>" class="btn btn-primary">
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <div class="table-responsive">
                                <table id="datatable1" style="width: 100%;" class="table table-hover">
                                    <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Total Places</th>

                                        <td align="center">Remove </th>
                                        <td align="center">Update</th>

                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($location->location_id); ?></td>
                                            <td><?php echo e($location->location_title); ?></td>
                                            <td><?php echo e(count($location->places)); ?></td>
                                            <td align="center"><a href="<?php echo e(route('admin.locations',['action'=>'delete','location'=>$location->location_id])); ?>"><i  style="color: #b21f2d;cursor:pointer;" class="fa fa-trash"></i> </a> </td>
                                            <td align="center"><a href="<?php echo e(route('admin.locations',['action'=>'update','location'=>$location->location_id])); ?>"><i  style="cursor: pointer" class="fa fa-edit"></i> </a> </td>

                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/onlinetutor/resources/views/admin/locations/index.blade.php ENDPATH**/ ?>