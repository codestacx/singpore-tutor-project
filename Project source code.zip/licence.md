This project is developed and designed by the @codestacx. 

/*
Theme Name: Website For online Tutor
Author: Muhammad Atif 
Author URI: 
Description: This web application is developed by codestacx
Tags: education, online education ,teaching , tutors
Requires PHP: 7.0+
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: education
*/
