var ajaxServer = {
    get:()=>{

    }

}
