<style>

</style>
<div class="container">

    <div class="container-fluid">

        <div  class="row bg-light" >
            <div class="col">

                <span style="text-align: center">
                    <h6 style="margin-top: 15px;color: coral"> FAST & EFFICIENT PROCESS </h6>
                    <h4 style="font-family: cursive">
                        Engage Your Ideal <br/>
                        Home Tutor in 3 Easy Steps:
                    </h4>
                    <hr/>
                </span>

                <div class="col content-steps" style="flex-direction: column">


                    <div style="flex: 1;margin: 10px">
                            <span>
                                <table class="" id="">
                                          <tr>
                                                <td style="margin-right: 10px">
                                                 <button type="button" class="btn btn-warning round-btn"> 1</button>
                                            </td>
                                              <td style="">
                                                  <span style="margin-left: 10px;color: darkorange;font-size: 22px;font-weight: 600;font-family: cursive;margin-bottom: 5px;">
                                    Request
                                </span>
                                <br/>
                                <small style="margin-left: 10px;font-style: italic;">For A Home Tutor ViaForm / Phone-Call</small>

                                              </td>

                                          </tr>
                                        </table>



                        </span>
                    </div>

                    <div style="flex: 1;margin: 10px">

                            <span>

                                 <table class="" id="">
                                          <tr>
                                                <td style="margin-right: 10px">
                                                 <button type="button" class="btn btn-info round-btn"> 2</button>
                                            </td>
                                              <td style="">
                                                  <span style="margin-left: 10px;color: #17a2b8;font-size: 22px;font-weight: 600;font-family: cursive;margin-bottom: 5px;">
                                    Select
                                </span>
                                <br/>
                                <small style="margin-left: 10px;font-style: italic;">From Our ComprehensiveList of Tutor Profiles</small>

                                              </td>
                                          </tr>
                                        </table>

                                            </span>
                    </div>

                    <div style="flex: 1;margin: 10px">
                         <span>
                                               <table class="" id="">
                                          <tr>
                                                <td style="margin-right: 10px">
                                                 <button type="button" class="btn btn-danger round-btn"> 3</button>
                                            </td>
                                              <td style="">
                                                  <span style="margin-left: 10px;color: #dc3545;font-size: 22px;font-weight: 600;font-family: cursive;margin-bottom: 5px;">
                                    Confirm
                                </span>
                                <br/>
                                <small style="margin-left: 10px;font-style: italic;">Your Selected Tutor with
Our Friendly Coordinators</small>
                                              </td>
                                          </tr>
                                        </table>
                                            </span>
                    </div>

                </div>

            </div>
            <div style="" class="col">
                <img src="{{asset('img/madamwithbacha.jpg')}}" style="border-radius: 10px"/>
            </div>

        </div>
    </div>



</div>
