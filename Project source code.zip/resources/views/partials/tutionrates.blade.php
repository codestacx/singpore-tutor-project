<div class="container">


    <h4 style="color: coral;text-align: center;margin-top: 15px; font-size: 28px; font-family: cursive;"> Tution Rates </h4>
    <br/>
    <table class="table table-hover tutionrates" style="width: 100%">

        <thead>
        <tr style="background-color: #1abc9c;color: #f7fafc">
            <th></th>
            <th>Part Time Tutors</th>
            <th>Full Time Tutors</th>
            <th>Ex/Current MOE Teachers</th>
        </tr>
        <tbody>


           <tr>
               <th id="level_"> Primary </th>
               <td> 10202</td>
               <td> 10202</td>
               <td> 10202</td>
           </tr>
           <tr>
               <th id="level"> Primary </th>
               <td> 10202</td>
               <td> 10202</td>
               <td> 10202</td>
           </tr>
           <tr>
               <th id="level_"> Primary </th>
               <td> 10202</td>
               <td> 10202</td>
               <td> 10202</td>
           </tr>
        </tbody>
        </thead>
    </table>

</div>
