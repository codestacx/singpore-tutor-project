Please click the link to verify your account.

<a href="{{route('site.email-verification',['email'=>$email,'token'=>$token])}}">Verify</a>
