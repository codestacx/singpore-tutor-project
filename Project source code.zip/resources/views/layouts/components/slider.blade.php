<!-- ##### Hero Area Start ##### -->
<section class="hero-area bg-img bg-overlay-2by5" style="background-image: url({{asset('img/bg-img/bg1.jpg')}});">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <!-- Hero Content -->
                <div class="hero-content text-center">
                    <h2 style="font-size: 30px">Singapore’s Best Home Tuition Agency</h2>
                     <a href="#myModal" class="btn clever-btn" data-toggle="modal">Free Request a Tutor</a>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ##### Hero Area End ##### -->
