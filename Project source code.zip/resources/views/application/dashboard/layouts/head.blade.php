<link rel="stylesheet" href="{{asset('static/css/fontawesome/fontawesome-all.css')}}">
<link rel="stylesheet" href="{{asset('static/css/linearicons.css')}}">
<link rel="stylesheet" href="{{asset('static/css/themify-icons.css')}}">
<link rel="stylesheet" href="{{asset('static/css/owl.carousel.min.css')}}">
<link rel="stylesheet" href="{{asset('static/css/lightpick.css')}}">
<link rel="stylesheet" href="{{asset('static/css/jquery.mCustomScrollbar.min.css')}}">
<link rel="stylesheet" href="{{asset('static/css/jquery-ui.css')}}">
<link rel="stylesheet" href="{{asset('static/css/tipso.css')}}">
<link rel="stylesheet" href="{{asset('static/css/select2.min.css')}}">
<link rel="stylesheet" href="{{asset('static/css/main.css')}}">
<link rel="stylesheet" href="{{asset('static/css/dashboard.css')}}">
@yield('links')
