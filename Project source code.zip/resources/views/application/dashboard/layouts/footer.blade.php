<script src="{{asset('static/js/vendor/gmap3.min.js')}}"></script>
<script src="{{asset('static/js/vendor/jquery.mCustomScrollbar.concat.min.js')}}"></script>
<script src="{{asset('static/js/vendor/select2.min.js')}}"></script>
<script src="{{asset('static/js/vendor/readmore.js')}}"></script>
<script src="{{asset('static/js/vendor/jquery-ui.js')}}"></script>
<script src="{{asset('static/js/vendor/lightpick.js')}}"></script>
<script src="{{asset('static/js/vendor/tipso.js')}}"></script>
<script src="{{asset('static/js/vendor/owl.carousel.min.js')}}"></script>
<script src="{{asset('static/js/vendor/jquery.ui.touch-punch.js')}}"></script>
<script src="{{asset('static/js/main.js')}}"></script>
<script src="{{asset('static/js/vendor/tinymce/tinymce.min.js%3FapiKey=4cuu2crphif3fuls3yb1pe4qrun9pkq99vltezv2lv6sogci')}}"></script>

@yield('scripts')
