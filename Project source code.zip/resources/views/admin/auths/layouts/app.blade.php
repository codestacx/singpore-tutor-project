<!DOCTYPE html>
<html>
<head>
@include('admin.layouts.head')
</head>
<body>
<div class="container-fluid px-3">
   @yield('content')
</div>

@include('admin.auths.layouts.footer')
</body>
</html>
