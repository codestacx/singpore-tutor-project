@extends('admin.layouts.app')
@section('title','Dashboard')
@section('content')
    <!-- Counts Section -->
    <section class="dashboard-counts section-padding">
        <div class="container-fluid">

            <div class="alert alert-success">
                Welcome TO Website Administration Panel
            </div>
        </div>
    </section>
    <!-- Header Section-->

    <!-- Statistics Section-->
    <section class="statistics">

    </section>
    <!-- Updates Section -->
    <section class="mt-30px mb-30px">

    </section>
@endsection
