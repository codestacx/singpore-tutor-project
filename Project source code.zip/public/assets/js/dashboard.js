var Level = {
    addNewLevelRow:(id,title,is_active)=>{

      //  var gett = $("#title").val(title);
        var gett = document.getElementById('title');
       // var asd = $('#submit_btn').val();
       // $("#gadget_url").val("");
      //  $("#submit_btn").val('Update');
        // $("#level_id").val(id);
        // $("#title").val(title);
        // $("#is_active").val(is_active);
        console.log(id+"___"+title+"_"+gett);
    }
}
