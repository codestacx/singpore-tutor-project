$(function () {
    $('.summernote').summernote({
        height: 300
    });
});

